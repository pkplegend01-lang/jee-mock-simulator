export default function RootLayout({ children }) {
  return (
    <html>
      <body style={{ margin: 0, fontFamily: 'Segoe UI, Arial' }}>{children}</body>
    </html>
  );
}
