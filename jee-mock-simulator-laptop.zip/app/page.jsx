// The full simulator UI will be added after deploy.
export default function Home(){return (<div style={{padding:24}}>Upload PDF — simulator shell OK</div>);}